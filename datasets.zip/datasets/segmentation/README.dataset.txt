# Manga Translator (Segmentation) > 2023-04-28 10:06pm
https://universe.roboflow.com/tarehimself/manga-translator-segmentation

Provided by a Roboflow user
License: CC BY 4.0

